#include <iostream> // library input and output
#include <string>   // library string

#include "formula.h"

using namespace std;

int main()
{
    string title = "Flowchart - Menghitung Luas Bangun Datar (Persegi, Persegi Panjang, Lingkaran)";

    cout << title << endl;

    input_formula();

    return 0;
}
