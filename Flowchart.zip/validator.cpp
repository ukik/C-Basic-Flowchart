#include <iostream> // library input and output

using namespace std;

// Declaration
float validator(float value)
{
    cin >> value;
    while(cin.fail()) {
        cout << "Error! must be numbers" << endl;
        cin.clear();
        cin.ignore(256,'\n');
        cin >> value;
    }
    return value;
}
